package Projeto;

import java.util.Objects;

public class Livro {
    
    // Atributos
    int id;
    String titulo;
    String autor;
    int ano_publicacao;

    // Construtor
    public Livro(int id, String titulo, String autor, int ano_publicacao) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.ano_publicacao = ano_publicacao;
    }

    // Sobrescrevendo os métodos equals e hashCode para criar o grafo
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Livro livro = (Livro) o;
        return id == livro.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    // Sobrescrevendo toString para melhor visualização das informações do livro
    @Override
    public String toString() {
        return this.titulo + " de " + this.autor;
    }
}
